/*
 * Base3
 * Author: Diego Piccini da Todi, contact@diegopiccinidatodi.com
 * April, 2023
 */


public class BankAccount {

    public static void main(String[] args) {
        double amount;

        amount = 9.46;
        amount = amount + 46.00;

        System.out.print("This amount of $");
        System.out.print(amount);
        System.out.println(" will be added to your account.");
    }
}
