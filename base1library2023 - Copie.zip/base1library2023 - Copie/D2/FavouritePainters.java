/*
 * Base2
 * Author: Diego Piccini da Todi, contact@diegopiccinidatodi.com
 * April, 2023
 */

public class FavouritePainters {

    public static void main(String[] args) {
        System.out.println("Turner, Caravaggio, Klimt, Corot");
    }
}
